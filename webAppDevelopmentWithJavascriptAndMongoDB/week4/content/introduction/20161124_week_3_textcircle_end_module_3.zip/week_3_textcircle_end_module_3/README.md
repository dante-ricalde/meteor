Hi!

You need to run the command:

meteor npm install

before you can start up this project.
